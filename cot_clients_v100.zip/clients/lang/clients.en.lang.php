<?php
/**
 * Сlients plugin
 *
 * @package clients
 * @version 1.0
 * @author Alexeev Vlad
 */
defined('COT_CODE') or die('Wrong URL.');

$L['clients_clients'] = 'Сlients';
