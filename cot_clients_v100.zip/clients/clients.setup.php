<?php
/**
 * [BEGIN_COT_EXT]
 * Code=clients
 * Name=Вывод клиентов исполнителя
 * Description=Вывод клиентов исполнителя
 * Version=1.0
 * Date=01.10.2015
 * Author=Alexeev Vlad
 * Copyright=Alexeev Vlad (c) http://cmsworks.ru/users/alexvlad
 * Auth_guests=R
 * Lock_guests=W12345A
 * Auth_members=R
 * Lock_members=W12345A
 * Required_modules=projects
 * 
 * [END_COT_EXT]
 * [BEGIN_COT_EXT_CONFIG]
 * clientslimit=01:text::10:Кол-во клиентов для показа (0 - все)
 * [END_COT_EXT_CONFIG]
 */

/**
 * Сlients plugin
 *
 * @package clients
 * @version 1.0
 * @author Alexeev Vlad
 */

defined('COT_CODE') or die('Wrong URL');

?>