<?PHP
/**
 * reCAPTCHA Plugin for Cotonti
 *
 * @package recaptchag
 * @version 2.0
 * @author Alexeev vlad
 * @copyright Copyright (c) Alexeev vlad
 * @license Free
 */

$L['recaptcha_verification_failed'] = 'Go recheck reCAPTCHA!';
$L['recaptcha_no_sitekey'] = 'Get the secret code <a href=\"https://www.google.com/recaptcha/admin\">https://www.google.com/recaptcha/admin</a> and fill it in the plugin settings recaptcha';
?>