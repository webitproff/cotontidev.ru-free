<?PHP
/**
 * reCAPTCHA Plugin for Cotonti
 *
 * @package recaptchag
 * @version 2.0
 * @author Alexeev vlad
 * @copyright Copyright (c) Alexeev vlad
 * @license Free
 */

$L['recaptcha_verification_failed'] = 'Пройдите повторную проверку reCAPTCHA!';
$L['recaptcha_no_sitekey'] = 'Получите секретный код <a href=\"https://www.google.com/recaptcha/admin\">https://www.google.com/recaptcha/admin</a> и заполните его в настройках плагина recaptcha';
?>