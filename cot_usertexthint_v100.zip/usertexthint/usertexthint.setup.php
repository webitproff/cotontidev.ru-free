<?php
/* ====================
[BEGIN_COT_EXT]
Code=usertexthint
Name=Подсказки категорий
Description=Подсказка при выборе категории для пользователя
Version=1.0.0
Date=23.10.2017
Author=Alexeev Vlad
Copyright=cotontidev.ru
Notes=BSD License
Auth_guests=R
Lock_guests=12345A
Auth_members=RW
Lock_members=
Recommends_plugins=usercategories
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
column=01:string::usertext_hint:Укажите код экстраполя для подсказки
[END_COT_EXT_CONFIG]
==================== */

defined('COT_CODE') or die('Wrong URL');
