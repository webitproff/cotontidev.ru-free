<?php

defined('COT_CODE') or die('Wrong URL');

$L['savesearch'] = 'Сохраненные поиски';

$L['savesearch_star_set'] = 'Сохранить поиск';
$L['savesearch_star_unset'] = 'Поиск уже в сохраненных';

$L['savesearch_star_set_action'] = 'Поиск добавлен в сохраненные';
$L['savesearch_star_unset_action'] = 'Проект удален из сохраненных';

$L['savesearch_savedsearch'] = 'Сохраненный поиск в';
$L['savesearch_savedsearch_in_projects'] = 'проектах';
$L['savesearch_savedsearch_in_market'] = 'товарах';

$L['savesearch_empty'] = 'У Вас еще нет сохраненных поисков';