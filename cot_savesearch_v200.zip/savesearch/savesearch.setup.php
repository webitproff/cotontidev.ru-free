<?php
/* ====================
[BEGIN_COT_EXT]
Code=savesearch
Name=Save Search
Description=Поисковоя статистика, подсказки фраз, сохранение поисковых запросов
Version=2.0.0
Date=25.03.2019
Author=Alexeev Vlad
Copyright=cotontidev.ru
Notes=BSD License
Auth_guests=R
Lock_guests=12345A
Auth_members=RW
Lock_members=
Recommends_modules=market,projects,users
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
disable_guests=01:radio::0:Отключить отслеживание гостей
[END_COT_EXT_CONFIG]
==================== */

defined('COT_CODE') or die('Wrong URL');
