<?php

$R['savesearch_star_on'] = '<a href="{$url}" data-togglesavesearch=""><img src="plugins/savesearch/img/star-off.png"/> '.$L['savesearch_star_set'].'</a>';
$R['savesearch_star_off'] = '<a href="{$url}" data-togglesavesearch=""><img src="plugins/savesearch/img/star-on.png"/> '.$L['savesearch_star_unset'].'</a>';