<?php
/**
 * [BEGIN_COT_EXT]
 * Code=paycontacts
 * Name=Подписка на просмотр контактов
 * Category=Payments
 * Description=Описания нет
 * Version=1.0.1
 * Date=
 * Author=Alexeev Vlad
 * Copyright=Copyright (c) cotontidev.ru
 * Notes=
 * Auth_guests=R
 * Lock_guests=12345A
 * Auth_members=RW
 * Lock_members=12345A
 * Requires_modules=payments,users
 * Requires_plugins=
 * [END_COT_EXT]
 * 
 * [BEGIN_COT_EXT_CONFIG]
 * cost=01:string::200:Стоимость в месяц
 * extra=02:string::phone:Укажите экстраполя которые будут доступны после подписки в теге {_CONTACTS_SHOW}
 * [END_COT_EXT_CONFIG]
 */
?>