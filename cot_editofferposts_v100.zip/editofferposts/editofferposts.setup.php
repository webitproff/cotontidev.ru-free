<?php
/* ====================
[BEGIN_COT_EXT]
Code=editofferposts
Name=Редактирование переписки по предложению
Version=1.0
Author=Alexeev Vlad
Requires_plugins=projects
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
editusers=01:radio::0:Разрешить редактирование сообщения пользователям
[END_COT_EXT_CONFIG]
==================== */

defined('COT_CODE') or die('Wrong URL');
