<?php
/* ====================
[BEGIN_COT_EXT]
Name=Dialog System
Description=User communication with ajax update and send
Version=2.6.1
Date=2016-03-31
Author=Alexeev Vlad
Auth_guests=
Lock_guests=W12345A
Auth_members=RW
Lock_members=
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
turnajax=01:radio::1:
sound=02:radio::1:Включить звуковые оповещания
ajaxcheck=03:radio::1:Включить AJAX проверку новых сообщений
hideimport=04:radio::0:Скрыть функцию импорта сообщений в админке
hideset=05:hidden:::
timesend=06:string::120:Частота рассылки ( в минутах )
[END_COT_EXT_CONFIG]
==================== */

/**
 * DS setup file
 * @version 2.2
 * @package DS
 * @copyright (c) Alexeev Vlad
 */
