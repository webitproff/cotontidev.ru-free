/**
 * DS DB uninstall
 */

DROP TABLE IF EXISTS `cot_ds_msg`;
DROP TABLE IF EXISTS `cot_ds_dialog`;