<?php

defined('COT_CODE') or die('Wrong URL.');


$L['sberbankbilling_title'] = 'Информация об оплате';

$L['sberbankbilling_error_paid'] = 'Оплата прошла успешно. В ближайшее время услуга будет активирована!';
$L['sberbankbilling_error_done'] = 'Оплата прошла успешно.';
$L['sberbankbilling_error_incorrect'] = 'Некорректная подпись';
$L['sberbankbilling_error_otkaz'] = 'Отказ от оплаты.';
$L['sberbankbilling_error_title'] = 'Результат операции оплаты';
$L['sberbankbilling_error_fail'] = 'Оплата не произведена! Пожалуйста, повторите попытку. Если ошибка повторится, обратитесь к администратору сайта';

$L['sberbankbilling_redirect_text'] = 'Сейчас произойдет редирект на страницу оплаченной услуги. Если этого не произошло, перейдите по <a href="%1$s">ссылке</a>.';