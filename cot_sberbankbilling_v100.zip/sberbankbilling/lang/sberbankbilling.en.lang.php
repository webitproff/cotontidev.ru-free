<?php

defined('COT_CODE') or die('Wrong URL.');


$L['sberbankbilling_title'] = 'Информация об оплате';

$L['sberbankbilling_error_paid'] = 'Payment was successful. In the near future the service will be activated!';
$L['sberbankbilling_error_done'] = 'Payment was successful.';
$L['sberbankbilling_error_incorrect'] = 'The signature is incorrect!';
$L['sberbankbilling_error_otkaz'] = 'Failure to pay.';
$L['sberbankbilling_error_title'] = 'Result of the operation of payment';
$L['sberbankbilling_error_fail'] = 'Payment is not made! Please try again. If the problem persists, contact your site administrator';

$L['sberbankbilling_redirect_text'] = 'Now will redirect to the page of the paid services. If it does not, click <a href="%1$s">here</a>.';