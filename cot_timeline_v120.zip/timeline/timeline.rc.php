<?php

/**
 * [BEGIN_COT_EXT]
 * Hooks=rc
 * Order=99
 * [END_COT_EXT]
 */

/** 
   
  Разработка сайтов на cotonti, готовые плагины - cotontidev.ru
   
**/

defined('COT_CODE') or die('Wrong URL.');

cot_rc_link_file($cfg['plugins_dir'] . '/timeline/css/timeline.css');