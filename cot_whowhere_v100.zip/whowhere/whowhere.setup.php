<?php
/* ====================
[BEGIN_COT_EXT]
Code=whowhere
Name=Кто где
Category=community-social
Description=Список пользователей и их история просмотров
Version=1.0.0
Date=22.03.2019
Author=Alexeev Vlad
Copyright=copyright (c) cotontidev.ru
SQL=
Auth_guests=R
Lock_guests=W12345A
Auth_members=R
Lock_members=W12345A
Requires_modules=users
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
disable_guests=01:radio::0:Отключить отслеживание гостей
[END_COT_EXT_CONFIG]
==================== */

defined('COT_CODE') or die('Wrong URL');
