<?php
/* ====================
[BEGIN_COT_EXT]
Code=editoffer
Name=Редактирование предложений
Version=1.0
Author=Alexeev Vlad
Requires_plugins=projects
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
editoffertrue=01:radio::1:Разрешить редактирование предложения
showoffersall=02:radio::1:Показывать предложения всем
showpostssall=03:radio::1:Показывать переписку по предложению всем
[END_COT_EXT_CONFIG]
==================== */

defined('COT_CODE') or die('Wrong URL');
