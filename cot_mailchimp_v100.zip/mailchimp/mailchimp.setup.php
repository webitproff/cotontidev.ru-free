<?php
/* ====================
[BEGIN_COT_EXT]
Code=mailchimp
Name=API для mailchimp.com
Version=1.0.0
Date=04.10.2017
Author=Alex.Vlad
Copyright=(c) cotontidev.ru
SQL=
Auth_guests=RW1
Lock_guests=2345A
Auth_members=RW1
Lock_members=2345A
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
apikey=01:string:::Api Key
[END_COT_EXT_CONFIG]
==================== */

defined('COT_CODE') or die('Wrong URL');
