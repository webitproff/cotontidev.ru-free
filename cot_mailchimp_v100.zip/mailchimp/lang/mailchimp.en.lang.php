<?php
defined('COT_CODE') or die('Wrong URL.');
$L['info_desc'] = ' ';

$L['mailchimp_form_name'] = 'Your name';
$L['mailchimp_form_email'] = 'E-mail';
$L['mailchimp_form_phone'] = 'Phone';

$L['mailchimp_form_check_name'] = 'Ваше имя';
$L['mailchimp_form_check_email'] = 'Enter email address';
$L['mailchimp_form_check_phone'] = 'Enter Phone';

$L['mailchimp_form_send_default'] = '<div class="text-center">You have successfully subscribed</div>';
$L['mailchimp_form_send_withcomform'] = '<div class="text-center">the specified email address is sent a link to confirm your subscription.</div>';

$L['mailchimp_form_send_default_popup'] = 'You have successfully subscribed';
$L['mailchimp_form_send_withcomform_popup'] = 'the specified email address is sent a link to confirm your subscription.';

$L['mailchimp_mail_confirm_title'] = 'Confirm your membership';
$L['mailchimp_mail_confirm_body_title'] = 'In order to confirm the subscription, click on the following';
$L['mailchimp_mail_confirm_body_link'] = 'link';

$L['mailchimp_status_success'] = 'You have successfully subscribed';
$L['mailchimp_status_error'] = 'An error occurred';
