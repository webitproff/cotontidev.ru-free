<?php
defined('COT_CODE') or die('Wrong URL.');
$L['info_desc'] = ' ';

$L['mailchimp_form_name'] = 'Имя';
$L['mailchimp_form_email'] = 'Е-маил';
$L['mailchimp_form_phone'] = 'Телефон';

$L['mailchimp_form_check_name'] = 'Ваше имя';
$L['mailchimp_form_check_email'] = 'Укажите Е-маил';
$L['mailchimp_form_check_phone'] = 'Укажите телефон';

$L['mailchimp_form_send_default'] = '<div class="text-center">Подписка оформлена</div>';
$L['mailchimp_form_send_withcomform'] = '<div class="text-center">На указанный Е-маил отправлено письмо с ссылкой на подтверждение подписки.</div>';

$L['mailchimp_form_send_default_popup'] = 'Подписка оформлена';
$L['mailchimp_form_send_withcomform_popup'] = 'На указанный Е-маил отправлено письмо с ссылкой на подтверждение подписки.';

$L['mailchimp_mail_confirm_title'] = 'Подтверждение подписки';
$L['mailchimp_mail_confirm_body_title'] = 'Для того что бы подтвердить подписку, перейдите по следующей';
$L['mailchimp_mail_confirm_body_link'] = 'ссылке';

$L['mailchimp_status_success'] = 'Вы успешно подписались';
$L['mailchimp_status_error'] = 'Произошла ошибка';
