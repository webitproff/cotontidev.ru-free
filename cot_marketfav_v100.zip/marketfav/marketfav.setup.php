<?php
/* ====================
[BEGIN_COT_EXT]
Code=marketfav
Name=Избранные товары
Version=1.0
Date=26.06.2017
Author=Alexeev Vlad
Copyright=cotontidev.ru
Notes=BSD License
Auth_guests=R
Lock_guests=12345A
Auth_members=RW
Lock_members=
Recommends_modules=market
[END_COT_EXT]
==================== */

defined('COT_CODE') or die('Wrong URL');
