<?php

defined('COT_CODE') or die('Wrong URL.');

$L['exchangerates_cfg_upd_3600'] = '1 час';
$L['exchangerates_cfg_upd_7200'] = '2 часа';
$L['exchangerates_cfg_upd_10800'] = '3 часа';
$L['exchangerates_cfg_upd_21600'] = '6 часов';
$L['exchangerates_cfg_upd_43200'] = '12 часов';