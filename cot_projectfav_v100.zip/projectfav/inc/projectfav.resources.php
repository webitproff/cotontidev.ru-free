<?php

$R['projectfav_star_on'] = '<a href="{$url}" data-toggleprojectfav="{$id}"><img src="plugins/projectfav/img/star-off.png"/> '.$L['projectfav_star_set'].'</a>';
$R['projectfav_star_off'] = '<a href="{$url}" data-toggleprojectfav="{$id}"><img src="plugins/projectfav/img/star-on.png"/> '.$L['projectfav_star_unset'].'</a>';