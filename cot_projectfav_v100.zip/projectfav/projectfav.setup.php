<?php
/* ====================
[BEGIN_COT_EXT]
Code=projectfav
Name=Избранные проекты
Description=Добавление/Удаление проектов в "Избранное"
Version=1.0.0
Date=22.10.2017
Author=Alexeev Vlad
Copyright=cotontidev.ru
Notes=BSD License
Auth_guests=R
Lock_guests=12345A
Auth_members=RW
Lock_members=
Recommends_modules=projects
[END_COT_EXT]
==================== */

defined('COT_CODE') or die('Wrong URL');
