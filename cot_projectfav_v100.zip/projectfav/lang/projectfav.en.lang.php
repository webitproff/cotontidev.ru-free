<?php

defined('COT_CODE') or die('Wrong URL');

$L['projectfav'] = 'Избранные проекты';

$L['projectfav_star_set'] = 'Добавить в избранное';
$L['projectfav_star_unset'] = 'В избранном';

$L['projectfav_star_set_action'] = 'Проект добавлен в избранное';
$L['projectfav_star_unset_action'] = 'Проект удален из избранного';

$L['projectfav_empty'] = 'У Вас еще нет избранных проектов';