<?php defined('COT_CODE') or die('Wrong URL');
/* ====================
[BEGIN_COT_EXT]
Hooks=tools
[END_COT_EXT]
==================== */
require_once cot_incfile('sendpulse', 'plug');

require_once cot_incfile('sendpulse', 'plug', 'tools');
