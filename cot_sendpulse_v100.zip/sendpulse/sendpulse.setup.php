<?php
/* ====================
[BEGIN_COT_EXT]
Code=sendpulse
Name=API для sendpulse.com
Version=1.0.0
Date=2017-02-18
Author=Alex.Vlad
Copyright=(c) cotontidev.ru
SQL=
Auth_guests=RW1
Lock_guests=2345A
Auth_members=RW1
Lock_members=2345A
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
apiuserid=01:string:::ID
apisecret=02:string:::SECRET
apiform=03:text::Имя&Name|Телефон&Phone:Поля формы ( разделяя поля символом | и перевод символом & где Рус&Англ)
[END_COT_EXT_CONFIG]
==================== */

defined('COT_CODE') or die('Wrong URL');
