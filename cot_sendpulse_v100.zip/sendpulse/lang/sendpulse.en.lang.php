<?php
defined('COT_CODE') or die('Wrong URL.');
$L['info_desc'] = ' ';

$L['sendpulse_form_email'] = 'E-mail';

$L['sendpulse_form_check_email'] = 'Enter email address';

$L['sendpulse_form_send_default'] = '<div class="text-center">Subscription</div>';
$L['sendpulse_form_send_withcomform'] = '<div class="text-center">the specified email address is sent a link to confirm your subscription.</div>';

$L['sendpulse_mail_confirm_title'] = 'Confirm your membership';
$L['sendpulse_mail_confirm_body_title'] = 'In order to confirm the subscription, click on the following';
$L['sendpulse_mail_confirm_body_link'] = 'link';

$L['sendpulse_status_success'] = 'You have successfully subscribed';
$L['sendpulse_status_error'] = 'An error occurred';