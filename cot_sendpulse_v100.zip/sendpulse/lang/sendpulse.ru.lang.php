<?php
defined('COT_CODE') or die('Wrong URL.');
$L['info_desc'] = ' ';

$L['sendpulse_form_email'] = 'Е-маил';

$L['sendpulse_form_check_email'] = 'Укажите Е-маил';

$L['sendpulse_form_send_default'] = '<div class="text-center">Подписка оформлена</div>';
$L['sendpulse_form_send_withcomform'] = '<div class="text-center">На указанный Е-маил отправлено письмо с ссылкой на подтверждение подписки.</div>';

$L['sendpulse_mail_confirm_title'] = 'Подтверждение подписки';
$L['sendpulse_mail_confirm_body_title'] = 'Для того что бы подтвердить подписку, перейдите по следующей';
$L['sendpulse_mail_confirm_body_link'] = 'ссылке';

$L['sendpulse_status_success'] = 'Вы успешно подписались';
$L['sendpulse_status_error'] = 'Произошла ошибка';

