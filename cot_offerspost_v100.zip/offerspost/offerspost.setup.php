<?php defined('COT_CODE') or die('Wrong URL');
/* ====================
[BEGIN_COT_EXT]
Code=offerspost
Name=Просмотр сообщений по предложениям
Version=1.0
Date=2015-09-21
Author=Alexeev Vlad
Notes=
Auth_guests=R
Lock_guests=2345A
Auth_members=R
Lock_members=2345
Requires_modules=projects
Requires_plugins=
Recommends_modules=
Recommends_plugins=
[END_COT_EXT]

==================== */