<?php
/** ====================
 * [BEGIN_COT_EXT]
 * Code=checkextrafields
 * Name=Проверка экстраполей на заполнение
 * Description=Создание конфигураций для разных категорий
 * Version=1.0.0
 * Author=Alexeev Vlad
 * Copyright=Copyright (c) cotontidev.ru
 * Auth_guests=RW
 * Lock_guests=12345A
 * Auth_members=RW1
 * Lock_members=2345A
 * [END_COT_EXT]
 * ==================== */


defined('COT_CODE') or die('Wrong URL');
