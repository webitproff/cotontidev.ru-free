/* Drops all comments data completely */
DROP TABLE IF EXISTS `cot_ls_regions`;
DROP TABLE IF EXISTS `cot_ls_cities`;
