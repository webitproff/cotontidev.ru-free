<?php
/* ====================
[BEGIN_COT_EXT]
Code=authbyuser
Name=Аутентификация через пользователя
Description=Аутентификация через пользователя
Version=1.0.0
Date=10.10.2017
Author=Alexeev Vlad
Copyright=Copyright (c) cotontidev.ru
Notes=
Auth_guests=R
Lock_guests=W12345A
Auth_members=R
Lock_members=
[END_COT_EXT]
==================== */

defined('COT_CODE') or die('Wrong URL');
