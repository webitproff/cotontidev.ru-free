<?php

/**
 * [BEGIN_COT_EXT]
 * Code=alfabank
 * Name=Alfabank
 * Category=Payments
 * Description=Alfabank billing system
 * Version=1.0.0
 * Date=
 * Author=Alexeev Vlad
 * Copyright=Copyright (c) cotontidev.ru
 * Notes=
 * Auth_guests=R
 * Lock_guests=12345A
 * Auth_members=RW
 * Lock_members=12345A
 * Requires_modules=payments
 * [END_COT_EXT]
 *
 * [BEGIN_COT_EXT_CONFIG]
 * alfabank_username=01:string:::Логин магазина
 * alfabank_password=02:string:::Пароль магазина
 * alfabank_getaway=03:string:::Платежный шлюз
 * [END_COT_EXT_CONFIG]
 */
?>