<?php
/* ====================
[BEGIN_COT_EXT]
Code=fastpassrecover
Name=Востановление пароля без подтверждения по email
Category=
Description=
Version=1.0.0
Date=26.04.2017
Author=Alexeev Vlad
Copyright=Cotontidev.ru
Notes=BSD License
SQL=
Auth_guests=R
Lock_guests=12345A
Auth_members=R
Lock_members=12345A
Requires_plugins=
[END_COT_EXT]
==================== */

defined('COT_CODE') or die('Wrong URL');

?>