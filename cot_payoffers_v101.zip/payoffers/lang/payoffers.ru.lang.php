<?php

defined('COT_CODE') or die('Wrong URL.');

$L['payoffers_add_notpaid_done'] = 'Предложение добавленно, вам осталось зарезервировать сумму в размере ';

$L['payoffers_buy_title'] = 'Оплата комиссии';
$L['payoffers_buy_paydesc'] = 'Комиссия за предложение в проекте ';
$L['payoffers_buy_returndesc'] = 'Возврат зарезервированой комиссии за предложение в проекте ';
$L['payoffers_cost'] = 'Стоимость';
$L['payoffers_buy'] = 'Оплатить комиссию';
$L['payoffers_buy_rezerv'] = ' зарезервирована на сайте.';

$L['payoffers_refuse_pay_header'] = 'Комиссия возвращена.';
$L['payoffers_refuse_pay_body'] = 'Здравствуйте, {$offeruser_name}. '."\n\n".'Вам возвращена комиссия за предложение по проекту «{$prj_name}».'."\n\n".'{$link}';