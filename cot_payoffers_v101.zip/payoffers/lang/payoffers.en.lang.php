<?php

defined('COT_CODE') or die('Wrong URL.');

$L['payoffers_add_notpaid_done'] = 'Proposed additions , all you have to reserve an amount of ';

$L['payoffers_buy_title'] = 'payment of a commission';
$L['payoffers_buy_paydesc'] = 'The Commission proposal for the project ';
$L['payoffers_buy_returndesc'] = 'Returns are reserved for the Commission proposal in the draft ';
$L['payoffers_cost'] = 'Price';
$L['payoffers_buy'] = 'pay commission';
$L['payoffers_buy_rezerv'] = ' reserved online.';

$L['payoffers_refuse_pay_header'] = 'The Commission returned .';
$L['payoffers_refuse_pay_body'] = 'Hello, {$offeruser_name}. '."\n\n".'Refunded commission project proposal «{$prj_name}».'."\n\n".'{$link}';