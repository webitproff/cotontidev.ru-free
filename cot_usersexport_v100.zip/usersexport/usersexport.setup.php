<?php
/* ====================
[BEGIN_COT_EXT]
Code=usersexport
Name=Users Export
Description=Экспорт пользователей по группам
Version=1.0.0
Date=12.09.2017
Author=Alexeev Vlad
Copyright=Copyright (c) cotontidev.ru Team 2015-2017
SQL=
Auth_guests=R
Lock_guests=W12345A
Auth_members=RW
Lock_members=12345
[END_COT_EXT]
==================== */

defined('COT_CODE') or die('Wrong URL');
