<?php

defined('COT_CODE') or die('Wrong URL.');

$L['molliebilling_title'] = 'Mollie';
$L['plu_title'] = 'Mollie';

$L['molliebilling_error_api'] = 'Произошла ошибка.';
$L['molliebilling_error_process'] = 'Платеж находится на проверке. Пожалуйста, подождите.';
$L['molliebilling_error_paid'] = 'Оплата прошла успешно. В ближайшее время услуга будет активирована!';
$L['molliebilling_error_done'] = 'Оплата прошла успешно.';
$L['molliebilling_error_title'] = 'Результат операции оплаты';
$L['molliebilling_error_fail'] = 'Оплата не произведена! Пожалуйста, повторите попытку. Если ошибка повторится, обратитесь к администратору сайта';

?>