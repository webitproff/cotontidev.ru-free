<?php

/**
 * [BEGIN_COT_EXT]
 * Hooks=projects.preview.save.first
 * [END_COT_EXT]
 */

defined('COT_CODE') or die('Wrong URL');

require_once cot_incfile('payprojects', 'plug', 'pay');
