<?php
defined('COT_CODE') or die('Wrong URL');

$L["payprojects_project"] = "проекта";
$L["payprojects_job"] = "вакансии";
$L["payprojects_konkurs"] = 'проекта "в офис"';
$L["payprojects"] = 'Размещение';

$L["payprojects_project_price"] = 'Стоимоcть размещения';