<?php
/**
 * [BEGIN_COT_EXT]
 * Code=payProjects
 * Name=payProjects
 * Category=Other
 * Description=Платное добавление проектов
 * Version=1.0.0
 * Date=19.08.2017
 * Author=Alexeev Vlas
 * Copyright=Copyright (c) cotontidev.ru
 * Notes=
 * Auth_guests=R
 * Lock_guests=12345A
 * Auth_members=RW
 * Lock_members=12345A
 * Requires_modules=projects
 * Requires_plugins=payprjtop
 * [END_COT_EXT]
 *
 * [BEGIN_COT_EXT_CONFIG]
 * prj_cost=01:string::50|150|300:Стоимость размешения проекта (тип1|тип2)
 * discount_forpro=02:string::10:Скидка % для PRO
 * [END_COT_EXT_CONFIG]
 */
?>