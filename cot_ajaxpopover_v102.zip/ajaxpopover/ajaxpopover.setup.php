<?php
/**
 * [BEGIN_COT_EXT]
 * Code=ajaxpopover
 * Name=Ajax Popover
 * Description=Загрузка информации о профиле,проекте,портфолио в Popover
 * Version=1.0.2
 * Date=2016.01.04
 * Author=Alexeev Vlad
 * Copyright=Copyright (c) Cotontidev.ru
 * Notes=
 * Auth_guests=R
 * Lock_guests=W12345A
 * Auth_members=R
 * Lock_members=W12345A
 * [END_COT_EXT]
 *
 * [BEGIN_COT_EXT_CONFIG]
 * framework=01:select:bootstrap,custom:bootstrap:Framework
 * bootstrappopovercss=02:radio::1:Включить пользовательскую ширину Popover?
 * [END_COT_EXT_CONFIG]
 */
defined('COT_CODE') or die('Wrong URL.');
