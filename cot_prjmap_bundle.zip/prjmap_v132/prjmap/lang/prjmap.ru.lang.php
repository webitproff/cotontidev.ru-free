<?php
/**
 * Projects on google maps
 * @Version 1.2
 * @package prjmap
 * @copyright (c) Alexeev Vlad
 */

defined('COT_CODE') or die('Wrong URL.');

$L['info_desc'] = 'Отображение проектов на карте Google';

$L['cfg_type'] = 'Тип карты<br /><small>1 - обычная карта<br />2 - изображение со спутника<br />3 - гибрид изображения со спутника и обычной карты<br />4 - карта ландшафта</small>';
