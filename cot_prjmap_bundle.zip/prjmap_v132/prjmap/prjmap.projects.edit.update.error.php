<?php

/* ====================
  [BEGIN_COT_EXT]
  Hooks=projects.edit.update.error
  [END_COT_EXT]
  ==================== */

defined('COT_CODE') or die('Wrong URL.');

$ritem['item_adr'] = cot_import('ritem_adr', 'P', 'TXT'); 
