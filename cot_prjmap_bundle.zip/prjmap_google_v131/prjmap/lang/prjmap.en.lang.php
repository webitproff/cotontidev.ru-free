<?php
/**
 * Projects on google maps
 * @Version 1.2
 * @package prjmap
 * @copyright (c) Alexeev Vlad
 */

defined('COT_CODE') or die('Wrong URL.');

$L['info_desc'] = 'Displaying projects on Google';

$L['cfg_type'] = 'Card Type:<br /><small>1 - the usual card<br />2 - satellite image<br />3 - hybrid satellite images and map the usual<br />4 - terrain map</ small>';
