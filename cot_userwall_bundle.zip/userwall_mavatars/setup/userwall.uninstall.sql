/* Drops all comments data completely */
DROP TABLE IF EXISTS `cot_com`;