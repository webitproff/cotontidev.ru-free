<?php
/* ====================
[BEGIN_COT_EXT]
Code=userwall
Name=Стена пользователя, лайки постов
Category=community-social
Description=Стена для постов в профиль пользователя, лайки постов, общий счетчик лайков
Version=1.0.1
Date=2016-10-09
Author=Alexeev Vlad
Copyright=cotontidev.ru
Notes=BSD License
Auth_guests=R
Lock_guests=12345A
Auth_members=RW
Lock_members=
Recommends_modules=users
[END_COT_EXT]
==================== */

defined('COT_CODE') or die('Wrong URL');
