<?php
/**
 * Plugin Title & Subtitle
 */

$L['info_desc'] = 'Banner with statistics.';