/**
 * Events removes projects data
 */

DROP TABLE IF EXISTS `cot_eventindicator`;