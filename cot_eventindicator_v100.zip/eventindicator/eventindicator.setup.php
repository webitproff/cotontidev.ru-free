<?php defined('COT_CODE') or die('Wrong URL');
/* ====================
[BEGIN_COT_EXT]
Code=eventindicator
Name=Event Indicator
Description=Индикатор новых событий в сделке/проекте
Version=1.0.0
Date=28.03.2017
Author=Alexeev Vlad
Copyright=cotontidev.ru
Notes=
Auth_guests=RW
Lock_guests=2345A
Auth_members=RW
Lock_members=2345
Recommends_modules=projects
Recommends_plugins=sbr
[END_COT_EXT]
==================== */