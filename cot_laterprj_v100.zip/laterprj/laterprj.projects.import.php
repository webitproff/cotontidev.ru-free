<?php

/**
 * [BEGIN_COT_EXT]
 * Hooks=projects.add.add.import,projects.edit.update.import
 * [END_COT_EXT]
 */
defined('COT_CODE') or die('Wrong URL.');

$ritem['item_laterprj'] = cot_import_date('rlaterprj');