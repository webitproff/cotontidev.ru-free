<?php
/**
 * [BEGIN_COT_EXT]
 * Code=laterprj
 * Name=Отложенная публикация проекта
 * Description=Отложенная публикация проекта
 * Version=1.0.0
 * Date=13.10.2017
 * Author=Alexeev Vlad
 * Copyright=Copyright (c) Cotontidev.ru
 * Notes=
 * Auth_guests=RW
 * Lock_guests=12345A
 * Auth_members=RW
 * Lock_members=12345A
 * Requires_modules=projects
 * Requires_plugins=
 * [END_COT_EXT]
 */

?>