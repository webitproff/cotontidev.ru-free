<?php
/**
 * [BEGIN_COT_EXT]
 * Code=censored
 * Name=Фильтр запрещенных слов для проектов
 * Description=Выделяет и указывает кол-во запрещенных слов в тексте и заголовке
 * Version=1.0.0
 * Date=
 * Author=Alexeev Vlad
 * Copyright=cotontidev.ru
 * Notes=
 * Auth_guests=R
 * Lock_guests=12345A
 * Auth_members=RW
 * Lock_members=12345A
 * [END_COT_EXT]
 * 
 * [BEGIN_COT_EXT_CONFIG]
 * wordlist=01:textarea::Урод,сука:Список запрещенных слов (через запятую)
 * [END_COT_EXT_CONFIG]
 */
?>